# Real-Time Edge Detection Viewer

## ✅ Features
- Camera preview
- Real-time Canny edge detection (OpenCV C++)
- OpenGL ES rendering
- JNI integration

## ⚙ Setup
- Install NDK + OpenCV for Android
- Sync CMake with OpenCV .so files

## 🧠 Architecture
- Java/Kotlin for UI + Camera
- JNI bridges frame data
- C++ handles OpenCV processing
- Output is rendered using OpenGL textures

## 🖼 Demo
(Insert your demo GIF or screenshots here)
