package com.example.myedgeviewer;

public class NativeBridge {
    public static native byte[] processFrame(byte[] yuv, int width, int height);
}
