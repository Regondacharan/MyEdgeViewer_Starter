#include <jni.h>
#include <opencv2/opencv.hpp>
using namespace cv;

extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_example_myedgeviewer_NativeBridge_processFrame(JNIEnv *env, jclass, jbyteArray yuv, jint width, jint height) {
    jbyte* yuvData = env->GetByteArrayElements(yuv, nullptr);
    Mat yuvImg(height + height / 2, width, CV_8UC1, yuvData);
    Mat bgrImg;
    cvtColor(yuvImg, bgrImg, COLOR_YUV2BGR_NV21);

    Mat edges;
    Canny(bgrImg, edges, 100, 200);
    cvtColor(edges, edges, COLOR_GRAY2RGBA);

    int size = edges.total() * edges.elemSize();
    jbyteArray result = env->NewByteArray(size);
    env->SetByteArrayRegion(result, 0, size, reinterpret_cast<jbyte*>(edges.data));
    env->ReleaseByteArrayElements(yuv, yuvData, 0);
    return result;
}
